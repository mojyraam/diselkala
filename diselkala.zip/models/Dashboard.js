var mongoose = require('mongoose')

var DashboardSchema = new mongoose.Schema({
    nam
})